# breadwallet-core
SPV bitcoin C library

[getting sarted](https://github.com/breadwallet/breadwallet-core/wiki)
